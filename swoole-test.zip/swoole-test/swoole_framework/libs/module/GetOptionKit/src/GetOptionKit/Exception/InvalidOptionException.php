<?php
namespace GetOptionKit\Exception;
use Exception;

class InvalidOptionException extends Exception { }



