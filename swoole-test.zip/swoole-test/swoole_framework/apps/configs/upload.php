<?php
$upload = array(
    'base_dir' => WEBPATH.'/uploads/',
);
return $upload;