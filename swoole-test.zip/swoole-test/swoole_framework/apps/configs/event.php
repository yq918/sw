<?php
$event['master'] = array(
    'type' => Swoole\Queue\MsgQ::class,
    'async' => true,
    ''
);
return $event;